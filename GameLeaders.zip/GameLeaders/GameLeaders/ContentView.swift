//
//  ContentView.swift
//  GameLeaders
//
//  Created by Justin Agudah on 4/21/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        List {
            Section {
                SportsEventDetailView(sectionName: "Passing Yards", playerOne: "H Hooker", playerTwo: "C Bazelak", teamOne: "TENN", teamTwo: "MIZ", statsOne: "15-19,\n225 YDS, 3 TD", statsTwo: "27-44,\n322 YDS,2 INT")
                
                SportsEventDetailView(sectionName: "Rushing Yards", playerOne: "T Evans", playerTwo: "T Badie", teamOne: "TENN", teamTwo: "MIZ", statsOne: "15 CAR,\n156 YDS, 3 TD", statsTwo: "21 CAR,\n41 YDS, 1 TD")
                
                SportsEventDetailView(sectionName: "Receiving Yards", playerOne: "V Jones Jr", playerTwo: "K Chism", teamOne: "TENN", teamTwo: "MIZ", statsOne: "7 REC,\n79 YDS, 1 TD", statsTwo: "4 REC,\n76 YDS")
            }header:{Text("Game Leaders")
                    .font(.title3)
                    .fontWeight(.heavy)
                    .foregroundColor(Color.black)
                .multilineTextAlignment(.leading)}
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
