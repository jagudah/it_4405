//
//  SportsEventDetailView.swift
//  GameLeaders
//
//  Created by Justin Agudah on 4/21/23.
//

import Foundation
import SwiftUI

struct SportsEventDetailView: View {
    var sectionName: String
    var playerOne: String
    var playerTwo: String
    var teamOne: String
    var teamTwo: String
    var statsOne: String
    var statsTwo: String
    
    init(sectionName: String, playerOne: String, playerTwo: String, teamOne: String, teamTwo: String, statsOne: String, statsTwo: String) {
        self.sectionName = sectionName
        self.playerOne = playerOne
        self.playerTwo = playerTwo
        self.teamOne = teamOne
        self.teamTwo = teamTwo
        self.statsOne = statsOne
        self.statsTwo = statsTwo
    }
    
    var body: some View {
        Section {
            HStack {
                VStack() {
                    Image(playerOne).resizable().frame(width:45, height: 45).clipShape(Circle())
                    Text(teamOne)
                        .font(.subheadline)
                        .multilineTextAlignment(.leading)
                }
                
                VStack() {
                    Text(playerOne).fontWeight(.bold).frame(alignment: .trailing)
                    Text(statsOne)
                        .font(.caption)
                        .fontWeight(.light)
                        .multilineTextAlignment(.trailing)
                }
                
                Divider()
                
                VStack {
                    Text(playerTwo)
                        .fontWeight(.bold)
                        .multilineTextAlignment(.leading)
                    Text(statsTwo)
                        .font(.caption)
                        .fontWeight(.light)
                        .multilineTextAlignment(.leading)
                }
                
                VStack {
                    Image(playerTwo).resizable().frame(width:45, height: 45).clipShape(Circle())
                    Text(teamTwo)
                        .font(.subheadline).frame(alignment: .center)
                }
            }
        } header: {Text(sectionName)
                .font(.subheadline)
                .fontWeight(.bold)
                .foregroundColor(Color.black)
                .multilineTextAlignment(.center)
                
            }
    }
}

struct SportsEventDetailView_Previews: PreviewProvider {
    static var previews: some View {
        SportsEventDetailView(sectionName: "Passing Yards", playerOne: "H Hooker", playerTwo: "C Bazelak", teamOne: "TENN", teamTwo: "MIZ", statsOne: "15-19,\n225 YDS, 3 TD", statsTwo: "27-44,\n322 YDS,\n2 INT")
    }
}
