//
//  GameLeadersApp.swift
//  GameLeaders
//
//  Created by Justin Agudah on 4/21/23.
//

import SwiftUI

@main
struct GameLeadersApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
