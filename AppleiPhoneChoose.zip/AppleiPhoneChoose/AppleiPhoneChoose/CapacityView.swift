//
//  CapacityView.swift
//  AppleiPhoneChoose
//
//  Created by Justin Agudah on 4/22/23.
//

import Foundation
import SwiftUI

struct CapacityView: View {
    var storageLabel: String
    var priceLabel: String
    
    init(storageLabel: String, priceLabel: String) {
        self.storageLabel = storageLabel
        self.priceLabel = priceLabel
    }
    
    var body: some View {
        VStack(alignment: .center) {
            Text(storageLabel)
                .font(.title)
            + Text("2")
                .font(.system(size: 15.0))
                .baselineOffset(9.0)
                
            Text(priceLabel)
                .font(.subheadline)
                .foregroundColor(Color.gray)
                .multilineTextAlignment(.center)
        }
        .frame(minWidth: 125)
        .padding()
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color(.sRGB, red: 0.8, green: 0.8, blue: 0.8, opacity: 1.0))
        )
    }
}

struct CapacityView_Previews: PreviewProvider {
    static var previews: some View {
        CapacityView(storageLabel: "128GB", priceLabel: "From $999 or $41.62/mo. before trade-in*")
    }
}
