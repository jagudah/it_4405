//
//  ContentView.swift
//  AppleiPhoneChoose
//
//  Created by Justin Agudah on 4/22/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack{
            Color(.sRGB,red:0.953,green: 0.953,blue:0.969,opacity:1.0)
            VStack {
                List {
                    Section {
                        Text("From $999 or $41.62/mo. before trade-in*")
                            .font(.callout)
                            .multilineTextAlignment(.center)
                    }
                    
                }
                
            }
            
            VStack(alignment: .leading) {
                Text("\nChoose your finish.")
                    .font(.title2)
                    .fontWeight(.bold)
                HStack {
                    ColorView(color: Color(.sRGB,red:0.694,green: 0.776,blue:0.851,opacity:1.0), labelString: "Sierra Blue")
                    ColorView(color: Color(.sRGB, red: 0.900, green: 0.900, blue: 0.900, opacity: 1.0), labelString: "Silver")
                }
                
                HStack {
                    ColorView(color: Color(.sRGB, red: 0.969, green: 0.925, blue: 0.843, opacity: 1.0), labelString: "Gold")
                    ColorView(color: Color(.sRGB, red: 0.376, green: 0.365, blue: 0.357, opacity: 1.0), labelString: "Graphite")
                }
                
                VStack(alignment: .leading) {
                    Text("\nChoose your capacity.")
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    Text("Your current iPhone X is a 64 GB model.")
                        .font(.subheadline)
                        .fontWeight(.regular)
                        .foregroundColor(Color.gray)
                    
                    Text("How much capacity is right for you?\n")
                        .font(.subheadline)
                        .fontWeight(.regular)
                        .foregroundColor(/*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
                }
                
                HStack {
                    CapacityView(storageLabel: "128GB", priceLabel: "From $999 or $41.62/mo. before trade-in*")
                    CapacityView(storageLabel: "256GB", priceLabel: "From $1099 or $45.79/mo. before trade-in*")
                }
                
                HStack {
                    CapacityView(storageLabel: "512GB", priceLabel: "From $1299 or $54.12/mo. before trade-in*")
                    CapacityView(storageLabel: "1TB", priceLabel: "From $1499 or $62.45/mo. before trade-in*")
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider{
    static var previews: some View {
        ContentView()
    }
}
