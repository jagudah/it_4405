//
//  ColorView.swift
//  AppleiPhoneChoose
//
//  Created by Justin Agudah on 4/22/23.
//

import Foundation
import SwiftUI

struct ColorView: View {
    var color = Color.clear
    var labelString = ""
    
    init(color: Color, labelString: String) {
        self.color = color
        self.labelString = labelString
    }
    
    var body: some View {
        VStack(alignment: .center) {
            Image(systemName: "circle.fill")
                .resizable()
                .foregroundColor(color)
                .frame(width: 30.0, height: 30.0)
                
                
            Text(labelString)
                .font(.title3)
                .multilineTextAlignment(.center)
        }
        .frame(minWidth: 150)
        .padding()
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color(.sRGB, red: 0.8, green: 0.8, blue: 0.8, opacity: 1.0))
        )
    }
}

struct ColorView_Previews: PreviewProvider {
    static var previews: some View {
        ColorView(color: Color(.sRGB,red:0.694,green: 0.776,blue:0.851,opacity:1.0), labelString: "Sierra Blue")
    }
}
