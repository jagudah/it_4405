//
//  AppleiPhoneChooseApp.swift
//  AppleiPhoneChoose
//
//  Created by Justin Agudah on 4/22/23.
//

import SwiftUI

@main
struct AppleiPhoneChooseApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
