//
//  ContentView.swift
//  Field Survey
//
//  Created by Justin Agudah on 5/3/23.
//

import SwiftUI

struct ContentView: View {
    let observationData: ObservationData? = ObservationsLoader.load(jsonFileName: "field_observations")
    
    var body: some View {
        NavigationView {
            List {
                if let observationData = observationData {
                    ForEach(observationData.observations) {observation in
                        ScrollView {
                            NavigationLink(destination: ObservationDetailView(observation: observation)) {
                                HStack {
                                    Image(observation.classification)
                                    
                                    VStack(alignment: .leading){
                                        Text(observation.title)
                                            .foregroundColor(.black)
                                            .bold()
                                        Text(dateToString(date: observation.date))
                                            .foregroundColor(.black)
                                    }
                                }
                            }
                            .navigationTitle("Field Survey")
                        }
                    }
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .frame(maxWidth: .infinity)
    }
}

private func dateToString(date: Date) -> String {
    let dateFormatter2 = DateFormatter()
    dateFormatter2.dateFormat = "MMMM dd, yyyy h:mm a"
    dateFormatter2.dateStyle = .medium
    dateFormatter2.timeStyle = .medium
    return dateFormatter2.string(from: date )
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
