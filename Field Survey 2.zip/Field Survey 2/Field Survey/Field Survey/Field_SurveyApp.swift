//
//  Field_SurveyApp.swift
//  Field Survey
//
//  Created by Justin Agudah on 5/3/23.
//

import SwiftUI

struct ObservationData: Codable, Identifiable {
    let id = UUID()
    var status: String
    var observations: [Observation]
    
    enum CodingKeys: String, CodingKey {
        case status
        case observations
    }
}

struct Observation: Codable, Identifiable, Hashable {
    let id = UUID()
    var classification: String
    var title: String
    var description: String
    var date: Date
    
    enum CodingKeys: String, CodingKey {
        case classification
        case title
        case description
        case date
    }
}

class ObservationsLoader {
    class func load(jsonFileName: String) -> ObservationData? {
        var observationData: ObservationData?
        let jsonDecoder = JSONDecoder()
        jsonDecoder.dateDecodingStrategy = .iso8601
        
        if let jsonFileUrl = Bundle.main.url(forResource: jsonFileName, withExtension: "json"),
           let jsonData = try? Data(contentsOf: jsonFileUrl) {
            observationData = try? jsonDecoder.decode(ObservationData.self, from: jsonData)
        }
        
        return observationData
    }
}

@main
struct Field_SurveyApp: App {
    let observationData: ObservationData?
    
    init() {
        let displayFormatter = DateFormatter()
        displayFormatter.dateFormat = "MMMM d, yyyy h:mm:ss a"
        
        observationData = ObservationsLoader.load(jsonFileName: "field_observations")
        if let observationData = observationData {
            print("Status: \(observationData.status)")
            for observation in observationData.observations {
                print("id = \(observation.id), classification = \(observation.classification), title = \(observation.title), description = \(observation.description), date = \(displayFormatter.string(from: observation.date))")
            }
        }
    }
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
