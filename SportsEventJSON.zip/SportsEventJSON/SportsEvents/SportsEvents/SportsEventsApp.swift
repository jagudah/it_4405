//
//  SportsEventsApp.swift
//  SportsEvents
//
//  Created by Justin Agudah on 5/1/23.
//

import SwiftUI

struct EventData: Codable, Identifiable {
    let id = UUID()
    var status: String
    var events: [Event]
    
    enum CodingKeys: String, CodingKey {
        case status
        case events
    }
}

struct Event: Codable, Identifiable, Hashable {
    let id = UUID()
    var sport: String
    var matchup: String
    var date: Date
    
    enum CodingKeys: String, CodingKey {
        case sport
        case matchup
        case date
    }
}

class EventsLoader {
    class func load(jsonFileName: String) -> EventData? {
        var eventData: EventData?
        let jsonDecoder = JSONDecoder()
        jsonDecoder.dateDecodingStrategy = .iso8601
        
        if let jsonFileUrl = Bundle.main.url(forResource: jsonFileName, withExtension: "json"),
           let jsonData = try? Data(contentsOf: jsonFileUrl) {
            eventData = try? jsonDecoder.decode(EventData.self, from: jsonData)
        }
        
        return eventData
    }
}

@main
struct SportsEventsApp: App {
    let eventData: EventData?
    
    init() {
        let displayFormatter = DateFormatter()
        displayFormatter.dateFormat = "MMMM d, yyyy h:mm a"
        
        eventData = EventsLoader.load(jsonFileName: "sports_events")
        if let eventData = eventData {
            print("Status: \(eventData.status)")
            for event in eventData.events {
                print("id = \(event.id), sport = \(event.sport), matchup = \(event.matchup), date = \(displayFormatter.string(from: event.date))")
            }            
        }
    }
    
    
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
