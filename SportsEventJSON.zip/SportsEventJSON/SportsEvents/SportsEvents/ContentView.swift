//
//  ContentView.swift
//  SportsEvents
//
//  Created by Justin Agudah on 5/1/23.
//

import SwiftUI
import UIKit


struct ContentView: View {
    let eventsData: EventData? = EventsLoader.load(jsonFileName: "sports_events")
    
    var body: some View {
        VStack {
            List {
                if let eventsData = eventsData {
                    ForEach(eventsData.events, id: \.self) { event in
                        HStack {
                            Image(event.sport)
                            VStack {
                                Text(event.matchup)
                                    .font(.headline)
                                Text(dateToString(date: event.date))
                                    .font(.subheadline)
                            }
                        }
                    }
                }
            }
        }
    }
}

private func dateToString(date: Date) -> String {
    let dateFormatter2 = DateFormatter()
    dateFormatter2.dateFormat = "MMMM dd, yyyy h:mm a"
    return dateFormatter2.string(from: date )
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
