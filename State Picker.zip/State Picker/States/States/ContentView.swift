//
//  ContentView.swift
//  States
//
//  Created by Justin Agudah on 5/1/23.
//

import SwiftUI

struct ContentView: View {
    
    let states  = [ "(AK) Alaska", "(AL) Alabama", "(AR) Arkansas", "(AS) American Samoa", "(AZ) Arizona", "(CA) California", "(CO) Colorado", "(CT) Connecticut", "(DC) District of Columbia", "(DE) Delaware", "(FL) Florida", "(GA) Georgia", "(GU) Guam", "(HI) Hawaii", "(IA) Iowa", "(ID) Idaho", "(IL) Illinois", "(IN) Indiana", "(KS) Kansas", "(KY) Kentucky", "(LA) Louisiana", "(MA) Massachusetts", "(MD) Maryland", "(ME) Maine", "(MI) Michigan", "(MN) Minnesota", "(MO) Missouri", "(MS) Mississippi", "(MT) Montana", "(NC) North Carolina", "(ND) North Dakota", "(NE) Nebraska", "(NH) New Hampshire", "(NJ) New Jersey", "(NM) New Mexico", "(NV) Nevada", "(NY) New York", "(OH) Ohio", "(OK) Oklahoma", "(OR) Oregon", "(PA) Pennsylvania", "(PR) Puerto Rico", "(RI) Rhode Island", "(SC) South Carolina", "(SD) South Dakota", "(TN) Tennessee", "(TX) Texas", "(UT) Utah", "(VA) Virginia", "(VI) Virgin Islands", "(VT) Vermont", "(WA) Washington", "(WI) Wisconsin", "(WV) West Virginia", "(WY) Wyoming" ]
    @State private var selectedState = "(AK) Alaska"
    
    var body: some View {
        VStack {
            Picker("Please choose a state", selection: $selectedState) {
                ForEach(states, id: \.self) {
                    Text($0)
                }
            }
            Text("Picked state: \(selectedState)")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
