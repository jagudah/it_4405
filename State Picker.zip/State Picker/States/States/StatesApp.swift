//
//  StatesApp.swift
//  States
//
//  Created by Justin Agudah on 5/1/23.
//

import SwiftUI

@main
struct StatesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
