//
//  StatesApp.swift
//  States
//
//  Created by Justin Agudah on 4/25/23.
//

import SwiftUI

@main
struct StatesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
