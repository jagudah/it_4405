//
//  DetailView.swift
//  States
//
//  Created by Justin Agudah on 4/30/23.
//

import Foundation
import SwiftUI
import UIKit

struct DetailView: View {
    let state: USState
    
    var body: some View {
        VStack(alignment: .center) {
            Text("#\(state.rank) - \(state.name)")
                .font(.title)
            Text("Current Population: \(state.pop)")
            Text("2018 Population: \(state.pop2018)")
            Text("2010 Population: \(state.pop2010)")
            Text("Current Population Density: \(String(format: "%g", state.density))")
        }
    }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView(state: USState.init(name: "Texas", rank: 2, pop: 1000, pop2018: 899, pop2010: 430, density: 7.32))
    }
}
