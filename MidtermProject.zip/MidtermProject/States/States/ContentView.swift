//
//  ContentView.swift
//  States
//
//  Created by Justin Agudah on 4/25/23.
//

import SwiftUI
import UIKit

struct ContentView: View {
    
    var states = USStates.list
    
    var body: some View {
        NavigationView {
            List(states, id: \.self) { usState in
                ScrollView {
                    NavigationLink(destination: DetailView(state: usState)) {
                        Text(usState.name)
                    }
                    .navigationTitle("US States")
                    .navigationBarTitleDisplayMode(.inline)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .frame(maxWidth: .infinity)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
