//
//  ObservationDetailView.swift
//  Field Survey
//
//  Created by Justin Agudah on 5/4/23.
//

import Foundation
import SwiftUI
import UIKit

private func dateToString(date: Date) -> String {
    let dateFormatter2 = DateFormatter()
    dateFormatter2.dateFormat = "MMMM dd, yyyy h:mm a"
    dateFormatter2.dateStyle = .medium
    dateFormatter2.timeStyle = .medium
    return dateFormatter2.string(from: date )
}

struct ObservationDetailView: View {
    let observation: Observation
    
    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Text("Observation")
                    .font(.largeTitle)
                    .bold()
            }
            
            HStack {
                Image(observation.classification)
                VStack(alignment: .leading) {
                    Text(observation.title)
                        .font(.headline)
                    Text(dateToString(date: observation.date))
                        .font(.subheadline)
                }
            }
            
            HStack {
                Text(observation.description)
                    .font(.subheadline)
            }
        }
    }
}

struct ObservationDetailView_Previews: PreviewProvider {
    static var previews: some View {
        ObservationDetailView(observation: Observation(classification: "mammal", title: "Rizzly Bear", description: "Will viciously rizz you up", date: Date()))
    }
}
