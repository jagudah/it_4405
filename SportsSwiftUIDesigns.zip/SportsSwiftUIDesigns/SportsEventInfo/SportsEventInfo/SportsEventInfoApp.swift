//
//  SportsEventInfoApp.swift
//  SportsEventInfo
//
//  Created by Justin Agudah on 4/21/23.
//

import SwiftUI

@main
struct SportsEventInfoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
