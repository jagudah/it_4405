//
//  ContentView.swift
//  SportsEventInfo
//
//  Created by Justin Agudah on 4/21/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            HStack {
                Image("football")
                Text("football")
            }
            
            HStack {
                Text("Matchup: Tennessee vs Missouri")
            }
            
            HStack {
                Text("When: October 2, 2021 at 11:30:00 AM")
            }
            
            HStack {
                Image("TNvsMO_Oct2_2022")
                    .resizable()
                    .scaledToFit()
            }
            
            HStack {
                Image("TNvsMO_GameLeaders")
                    .resizable()
                    .scaledToFit()
            }
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
