//
//  ContentView.swift
//  SportsEventListCell
//
//  Created by Justin Agudah on 4/17/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView  {
            List {
                HStack {
                    Image("basketball")
                    VStack {
                        Text("Portland at Orlando")
                        Text("Feb 23, 2017 at 10:00 AM")
                    }
                }
                
                HStack {
                    Image("soccer")
                    VStack {
                        Text("Edmonton at Washington")
                        Text("Feb 23, 2017 at 11:30 AM")
                    }
                }
                
                HStack {
                    Image("football")
                    VStack {
                        Text("Tennessee vs Missouri")
                        Text("Oct 2, 2021 at 11:30 AM")
                    }
                }
                
                HStack {
                    Image("baseball")
                    VStack {
                        Text("Nationals vs Dodgers")
                        Text("Oct 11, 2018 at 9:30 AM")
                    }
                }
                
                HStack {
                    Image("hockey")
                    VStack {
                        Text("NY Rangers at Toronto")
                        Text("Feb 23, 2017 at 11:30 AM")
                    }
                }
            }
            .navigationTitle("Sports Event")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
