//
//  SportsEventListCellApp.swift
//  SportsEventListCell
//
//  Created by Justin Agudah on 4/17/23.
//

import SwiftUI

@main
struct SportsEventListCellApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
